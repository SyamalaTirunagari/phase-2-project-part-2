/**
 * 
 */
/**
 * 
 */
module JdbcDatabaseDemo {
	requires java.sql;
}