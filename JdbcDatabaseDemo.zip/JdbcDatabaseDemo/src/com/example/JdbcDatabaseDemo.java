package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDatabaseDemo {
    public static void main(String[] args) {
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/";
        String username = "root";
        String password = "Syamala@12";

        String databaseName = "jdbc_demo_database";

        // JDBC connection
        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            System.out.println("Connected to the MySQL server!");

            // Create a database
            createDatabase(connection, databaseName);

            // Select the created database
            selectDatabase(connection, databaseName);

            // Drop the database
            dropDatabase(connection, databaseName);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createDatabase(Connection connection, String databaseName) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS " + databaseName;
            statement.executeUpdate(createDatabaseQuery);
            System.out.println("Database '" + databaseName + "' created successfully.");
        }
    }

    private static void selectDatabase(Connection connection, String databaseName) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            String selectDatabaseQuery = "USE " + databaseName;
            statement.executeUpdate(selectDatabaseQuery);
            System.out.println("Selected database: " + databaseName);
        }
    }

    private static void dropDatabase(Connection connection, String databaseName) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            String dropDatabaseQuery = "DROP DATABASE IF EXISTS " + databaseName;
            statement.executeUpdate(dropDatabaseQuery);
            System.out.println("Database '" + databaseName + "' dropped successfully.");
        }
    }
}
