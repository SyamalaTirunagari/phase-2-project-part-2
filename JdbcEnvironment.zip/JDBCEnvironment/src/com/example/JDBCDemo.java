package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCDemo {
    public static void main(String[] args) {
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/yourdb";
        String username = "root";
        String password = "Syamala@12";

        // JDBC connection
        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            System.out.println("Connected to the database!");

            // Perform database operations here

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
