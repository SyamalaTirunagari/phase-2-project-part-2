package com.example;

public class DbConstantPool {
	public static final String Driver_class="com.mysql.cj.jdbc.Driver";
	public static final String Db_url="jdbc:mysql://localhost:3306/";
	public static final String USERNAME="root";
	public static final String PASSWORD ="Syamala@12";
}