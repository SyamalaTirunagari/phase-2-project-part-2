/**
 * 
 */
/**
 * 
 */
module JDBCEnvironment {
	requires java.sql;
}