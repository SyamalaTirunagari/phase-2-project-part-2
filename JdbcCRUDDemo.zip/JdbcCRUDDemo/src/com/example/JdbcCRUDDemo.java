package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JdbcCRUDDemo {
    public static void main(String[] args) {
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/jdbc_demo";
        String username = "root";
        String password = "Syamala@12";

        // JDBC connection
        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            System.out.println("Connected to the database!");

            // Insert a new record
            insertRecord(connection, 3, "Alice", 70000.0);

            // Update an existing record
            updateRecord(connection, 1, "John Doe", 55000.0);

            // Delete a record
            deleteRecord(connection, 2);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertRecord(Connection connection, int id, String name, double salary) throws SQLException {
        String insertQuery = "INSERT INTO employees VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.setDouble(3, salary);

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " row(s) inserted.");
        }
    }

    private static void updateRecord(Connection connection, int id, String name, double salary) throws SQLException {
        String updateQuery = "UPDATE employees SET name = ?, salary = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            preparedStatement.setString(1, name);
            preparedStatement.setDouble(2, salary);
            preparedStatement.setInt(3, id);

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " row(s) updated.");
        }
    }

    private static void deleteRecord(Connection connection, int id) throws SQLException {
        String deleteQuery = "DELETE FROM employees WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
            preparedStatement.setInt(1, id);

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " row(s) deleted.");
        }
    }
}
