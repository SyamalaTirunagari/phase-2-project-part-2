/**
 * 
 */
/**
 * 
 */
module JdbcCRUDDemo {
	requires java.sql;
}