/**
 * 
 */
/**
 * 
 */
module JDBCDEmo {
	requires java.sql;
}