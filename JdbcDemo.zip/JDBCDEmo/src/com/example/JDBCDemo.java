package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCDemo {
    public static void main(String[] args) {
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/jdbc_demo";
        String username = "root";
        String password = "Syamala@12";

        // JDBC connection
        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            System.out.println("Connected to the database!");

            // Create a Statement
            try (Statement statement = connection.createStatement()) {
                // Execute a query
                String query = "SELECT * FROM employees";
                try (ResultSet resultSet = statement.executeQuery(query)) {
                    // Process the ResultSet
                    while (resultSet.next()) {
                        int id = resultSet.getInt("id");
                        String name = resultSet.getString("name");
                        double salary = resultSet.getDouble("salary");
                        System.out.println("Employee ID: " + id + ", Name: " + name + ", Salary: " + salary);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

