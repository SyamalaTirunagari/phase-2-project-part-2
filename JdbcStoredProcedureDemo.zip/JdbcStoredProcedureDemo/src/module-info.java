/**
 * 
 */
/**
 * 
 */
module JdbcStoredProcedureDemo {
	requires java.sql;
}