package com.example;

import java.sql.*;

public class JdbcStoredProcedureDemo {
    public static void main(String[] args) {
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/jdbc_demo";
        String username = "root";
        String password = "Syamala@12";

        int employeeIdToRetrieve = 1; // Change this value to the desired employee ID

        // JDBC connection
        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            System.out.println("Connected to the database!");

            // Call the stored procedure
            callStoredProcedure(connection, employeeIdToRetrieve);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void callStoredProcedure(Connection connection, int employeeId) throws SQLException {
        try (CallableStatement callableStatement = connection.prepareCall("{CALL getEmployeeById(?)}")) {
            // Set input parameter
            callableStatement.setInt(1, employeeId);

            // Execute the stored procedure
            boolean hasResults = callableStatement.execute();

            // Process the result set (if any)
            while (hasResults) {
                try (ResultSet resultSet = callableStatement.getResultSet()) {
                    while (resultSet.next()) {
                        int id = resultSet.getInt("id");
                        String name = resultSet.getString("name");
                        double salary = resultSet.getDouble("salary");
                        System.out.println("Employee ID: " + id + ", Name: " + name + ", Salary: " + salary);
                    }
                }

                // Check for more results
                hasResults = callableStatement.getMoreResults();
            }
        } catch (SQLException e) {
            handleSQLException(e);
        }
    }

    private static void handleSQLException(SQLException e) {
        System.err.println("SQLException: " + e.getMessage());
        System.err.println("SQLState: " + e.getSQLState());
        System.err.println("VendorError: " + e.getErrorCode());
    }
}

